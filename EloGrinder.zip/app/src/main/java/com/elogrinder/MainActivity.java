package com.elogrinder;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView web;
    private final Map<String, Process> procs = new HashMap<>();
    private final Map<String, BufferedWriter> writers = new HashMap<>();
    private String pendingText, pendingKind;
    private static final int REQ_SAVE = 11, REQ_OPEN = 12;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#262421"));
        getWindow().setNavigationBarColor(Color.parseColor("#262421"));
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#262421"));
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/www/index.html");
        new Thread(this::copyWeights).start();
    }

    /** Copies bundled Maia nets from assets to internal storage (lc0 needs real file paths). */
    private void copyWeights() {
        try {
            File dir = new File(getFilesDir(), "maia");
            dir.mkdirs();
            String[] names = getAssets().list("maia");
            if (names == null) return;
            for (String n : names) {
                if (!n.endsWith(".gz")) continue;
                File o = new File(dir, n);
                if (o.exists() && o.length() > 0) continue;
                File tmp = new File(dir, n + ".tmp");
                try (InputStream in = getAssets().open("maia/" + n); OutputStream out = new FileOutputStream(tmp)) {
                    byte[] buf = new byte[65536]; int r;
                    while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
                }
                tmp.renameTo(o);
            }
        } catch (Exception ignored) {}
    }

    private void js(final String code) { runOnUiThread(() -> web.evaluateJavascript(code, null)); }

    class Bridge {
        @JavascriptInterface public boolean engineAvailable(String n) {
            return new File(getApplicationInfo().nativeLibraryDir, "lib" + n + ".so").exists();
        }
        @JavascriptInterface public String maiaDir() { return new File(getFilesDir(), "maia").getAbsolutePath(); }

        @JavascriptInterface public synchronized void engineStart(final String n) {
            Process old = procs.get(n);
            if (old != null && old.isAlive()) return;
            try {
                File exe = new File(getApplicationInfo().nativeLibraryDir, "lib" + n + ".so");
                ProcessBuilder pb = new ProcessBuilder(exe.getAbsolutePath());
                pb.directory(getFilesDir());
                pb.redirectErrorStream(true);
                final Process p = pb.start();
                procs.put(n, p);
                writers.put(n, new BufferedWriter(new OutputStreamWriter(p.getOutputStream())));
                new Thread(() -> {
                    try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                        String line;
                        while ((line = r.readLine()) != null) {
                            boolean keep = line.startsWith("bestmove") || line.startsWith("uciok") || line.startsWith("readyok")
                                    || (line.startsWith("info") && line.contains(" pv "));
                            if (keep) js("window.onEngine&&window.onEngine(" + JSONObject.quote(n) + "," + JSONObject.quote(line) + ")");
                        }
                    } catch (IOException ignored) {}
                }).start();
            } catch (Exception e) { toast("Engine failed: " + e.getMessage()); }
        }

        @JavascriptInterface public synchronized void engineSend(String n, String line) {
            try { BufferedWriter w = writers.get(n); if (w != null) { w.write(line + "\n"); w.flush(); } } catch (IOException ignored) {}
        }

        @JavascriptInterface public void toast(final String m) { runOnUiThread(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_SHORT).show()); }

        @JavascriptInterface public void saveFile(final String name, final String text) {
            pendingText = text;
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); i.putExtra(Intent.EXTRA_TITLE, name);
                startActivityForResult(i, REQ_SAVE);
            });
        }
        @JavascriptInterface public void pickFile(final String kind) {
            pendingKind = kind;
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
                startActivityForResult(i, REQ_OPEN);
            });
        }

        /** Google Play Games Saved Games hook. Needs your Play Console app id + play-services-games; see README. */
        @JavascriptInterface public String playGamesBackup(String json) {
            return "Google Play Games is not linked yet. Add your Play Games app ID (see README, section 'Play Games') and rebuild. Use 'Backup to storage' meanwhile.";
        }
        @JavascriptInterface public String playGamesRestore() { return playGamesBackup(""); }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try {
            if (req == REQ_SAVE && pendingText != null) {
                try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(pendingText.getBytes(StandardCharsets.UTF_8)); }
                js("window.onFileSaved&&window.onFileSaved()");
            } else if (req == REQ_OPEN) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                try (InputStream in = getContentResolver().openInputStream(u)) {
                    byte[] buf = new byte[65536]; int r;
                    while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
                }
                String text = bo.toString("UTF-8");
                js("window.onFilePicked&&window.onFilePicked(" + JSONObject.quote(pendingKind) + "," + JSONObject.quote(text) + ")");
            }
        } catch (Exception e) { Toast.makeText(this, "File error: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("window.handleBack?window.handleBack():false", v -> { if (!"true".equals(v)) finish(); });
    }

    @Override protected void onDestroy() {
        for (Process p : procs.values()) p.destroy();
        super.onDestroy();
    }
}
