// Stockfish game review + "Brilliant Trainer" coaching text
const VAL=MV,PN={p:'pawn',n:'knight',b:'bishop',r:'rook',q:'queen',k:'king'};
const CLS={brilliant:['!!','#1baca6','Brilliant'],great:['!','#5c8bb0','Great'],best:['★','#96bc4b','Best'],excellent:['✓','#96bc4b','Excellent'],good:['✓','#a3b18a','Good'],book:['♘','#a88865','Book'],inaccuracy:['?!','#e6b800','Inaccuracy'],mistake:['?','#e58f2a','Mistake'],miss:['✗','#ff7769','Miss'],blunder:['??','#ca3431','Blunder']};
const BOOK=[['Ruy Lopez','e4 e5 Nf3 Nc6 Bb5'],['Italian Game','e4 e5 Nf3 Nc6 Bc4'],['Giuoco Piano','e4 e5 Nf3 Nc6 Bc4 Bc5'],['Two Knights Defense','e4 e5 Nf3 Nc6 Bc4 Nf6'],['Scotch Game','e4 e5 Nf3 Nc6 d4'],['Petrov Defense','e4 e5 Nf3 Nf6'],["King's Gambit",'e4 e5 f4'],['Vienna Game','e4 e5 Nc3'],["King's Pawn Game",'e4 e5'],['Sicilian Defense','e4 c5'],['Sicilian Najdorf','e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 a6'],['French Defense','e4 e6 d4 d5'],['Caro-Kann Defense','e4 c6 d4 d5'],['Scandinavian Defense','e4 d5'],['Pirc Defense','e4 d6 d4 Nf6 Nc3 g6'],['Alekhine Defense','e4 Nf6'],["Queen's Gambit",'d4 d5 c4'],["Queen's Gambit Declined",'d4 d5 c4 e6 Nc3 Nf6'],['Slav Defense','d4 d5 c4 c6'],["King's Indian Defense",'d4 Nf6 c4 g6 Nc3 Bg7 e4 d6'],['Nimzo-Indian Defense','d4 Nf6 c4 e6 Nc3 Bb4'],["Queen's Indian Defense",'d4 Nf6 c4 e6 Nf3 b6'],['Grünfeld Defense','d4 Nf6 c4 g6 Nc3 d5'],['London System','d4 d5 Bf4'],['Dutch Defense','d4 f5'],["Queen's Pawn Game",'d4 d5'],['Indian Defense','d4 Nf6'],['English Opening','c4'],['Réti Opening','Nf3 d5 c4'],['Bird Opening','f4']];
const winPct=cp=>50+50*(2/(1+Math.exp(-0.00368208*cp))-1);
const accOf=l=>Math.max(0,Math.min(100,103.1668*Math.exp(-0.04354*l)-3.1669));
const cap=s=>s.charAt(0).toUpperCase()+s.slice(1);
const Q=n=>n===1?'point':'points';

// ---------- engine analysis ----------
function parseInfo(lines){const best={};for(const l of lines){if(l.indexOf('info')!==0)continue;const m=l.match(/multipv (\d+)/),k=m?+m[1]:1,sc=l.match(/score (cp|mate) (-?\d+)/),pv=l.match(/ pv (.+)$/);if(!sc||!pv)continue;const d=+((l.match(/depth (\d+)/)||[0,0])[1]);if(best[k]&&best[k].d>d)continue;const v=+sc[2];best[k]={d,cp:sc[1]==='cp'?v:(v>0?10000-v*10:-10000-v*10),mate:sc[1]==='mate'?v:null,pv:pv[1].trim().split(/\s+/).slice(0,8)}}return best}
function matOf(c){let s=0;c.board().forEach(r=>r.forEach(p=>{if(p)s+=(p.color==='w'?1:-1)*VAL[p.type]}));return s}
function fbEval(c){const mv=c.moves({verbose:true});const m=greedy(mv);return{cp:Math.round((matOf(c)*(c.turn()==='w'?1:-1))*100),mate:null,pv:m?[m.from+m.to+(m.promotion||'')]:[],alt:null}}
async function evalPos(fen){const c=new Chess(fen);
  if(c.in_checkmate())return{cp:-10000,mate:0,pv:[],alt:null};
  if(c.in_stalemate()||c.in_draw()||c.insufficient_material())return{cp:0,mate:null,pv:[],alt:null};
  if(!(await E.init('stockfish')))return fbEval(c);
  const L=await E.q('stockfish',['position fen '+fen,'go depth 13'],'bestmove',20000),b=parseInfo(L);
  if(!b[1])return fbEval(c);
  return{cp:b[1].cp,mate:b[1].mate,pv:b[1].pv,alt:b[2]?{cp:b[2].cp,pv:b[2].pv}:null}}
function positions(pgn){let c=new Chess();if(!c.load_pgn(pgn,{sloppy:true})){c=new Chess();const mt=pgn.replace(/\[[^\]]*\]/g,' ').replace(/\{[^}]*\}/g,' ');if(!c.load_pgn(mt,{sloppy:true}))return null}const hv=c.history({verbose:true}),hd=c.header(),t=hd.FEN?new Chess(hd.FEN):new Chess(),f=[t.fen()];hv.forEach(m=>{t.move({from:m.from,to:m.to,promotion:m.promotion});f.push(t.fen())});return{hv,hd,fens:f}}
async function analyzeGame(pgn,prog,cancelled){const P=positions(pgn);if(!P)return null;const res=[];
  for(let i=0;i<P.fens.length;i++){if(cancelled&&cancelled())return null;await new Promise(r=>setTimeout(r,0));res.push(await evalPos(P.fens[i]));prog&&prog((i+1)/P.fens.length)}return res}

// ---------- tactical helpers ----------
function flipTurn(fen){const p=fen.split(' ');p[1]=p[1]==='w'?'b':'w';p[3]='-';return p.join(' ')}
function pvSans(fen,pv,n){const c=new Chess(fen),o=[];for(const u of (pv||[]).slice(0,n)){const m=applyUci(c,u);if(!m)break;o.push(m.san)}return o}
function pvMatDelta(fen,pv,n){const c=new Chess(fen),side=c.turn(),m0=matOf(c);for(const u of (pv||[]).slice(0,n)){if(!applyUci(c,u))break}return(matOf(c)-m0)*(side==='w'?1:-1)}
function winningCaptures(fen){let c;try{c=new Chess(fen)}catch(e){return[]}const out=[];
  for(const m of c.moves({verbose:true})){if(!m.captured)continue;const cc=new Chess(fen);cc.move(m);const rec=cc.moves({verbose:true}).some(x=>x.to===m.to&&x.captured);const gain=VAL[m.captured]-(rec?VAL[m.piece]:0);if(gain>=2)out.push({m,gain})}
  return out.sort((a,b)=>b.gain-a.gain)}
function isSac(fen,uci){const c=new Chess(fen),m=applyUci(c,uci);if(!m||m.piece==='p'||m.piece==='k')return false;
  const pv=VAL[m.piece],cp=m.captured?VAL[m.captured]:0;let worst=0;
  for(const r of c.moves({verbose:true})){if(r.to!==m.to||!r.captured)continue;const cc=new Chess(c.fen());cc.move(r);const rec=cc.moves({verbose:true}).some(x=>x.to===m.to&&x.captured);worst=Math.max(worst,pv-cp-(rec?VAL[r.piece]:0))}
  return worst>=2}
function motifs(fen,uci){const c=new Chess(fen),m=applyUci(c,uci);if(!m)return[];const t=[];
  if(c.in_checkmate())t.push('delivers checkmate');else if(c.in_check())t.push('gives check');
  if(m.captured)t.push('captures the '+PN[m.captured]);
  if(m.promotion)t.push('promotes to a '+PN[m.promotion]);
  if(m.flags.indexOf('k')>=0||m.flags.indexOf('q')>=0)t.push('castles and tucks the king away');
  if(isSac(fen,uci))t.push('sacrifices the '+PN[m.piece]);
  try{const fl=new Chess(flipTurn(c.fen()));
    const tg=fl.moves({verbose:true,square:m.to}).filter(x=>x.captured&&(VAL[x.captured]>=VAL[m.piece]||VAL[x.captured]>=3));
    const n=tg.length+(c.in_check()?1:0);
    if(n>=2&&m.piece!=='k')t.push('forks '+tg.map(x=>'the '+PN[x.captured]+' on '+x.to).join(' and ')+(c.in_check()?' and the king':''));
    if(!c.in_check()&&fl.moves({verbose:true}).some(x=>{const z=new Chess(fl.fen());z.move(x);return z.in_checkmate()}))t.push('threatens checkmate');
  }catch(e){}
  return t}

// ---------- build the full review model ----------
// rough Elo estimate from average move accuracy (interpolated curve, not an official rating)
function estElo(a,n){if(n<6)return 0;const T=[[0,100],[30,300],[50,700],[65,1000],[75,1300],[85,1700],[92,2100],[97,2600],[100,3000]];for(let i=1;i<T.length;i++)if(a<=T[i][0]){const[x0,y0]=T[i-1],[x1,y1]=T[i];return Math.round((y0+(y1-y0)*(a-x0)/(x1-x0))/10)*10}return 3000}
function build(pgn,res,me){
  const P=positions(pgn),hv=P.hv,fens=P.fens,M=[],sans=hv.map(m=>m.san.replace(/[+#]/g,''));
  const cpW=k=>fens[k].split(' ')[1]==='w'?res[k].cp:-res[k].cp;
  const inBook=i=>{const s=sans.slice(0,i+1).join(' ');return BOOK.some(b=>b[1].indexOf(s)===0&&(b[1].length===s.length||b[1][s.length]===' '))};
  const gs=sans.join(' ');let opening='';BOOK.forEach(b=>{if((gs+' ').indexOf(b[1]+' ')===0&&b[1].length>=opening.length)opening=b[1]});
  const openName=(BOOK.find(b=>b[1]===opening)||[''])[0];
  let prevLoss=0;
  hv.forEach((m,i)=>{
    const r0=res[i],r1=res[i+1],uci=m.from+m.to+(m.promotion||''),best=r0.pv[0]||uci;
    const wB=winPct(r0.cp),wA=winPct(-r1.cp);let loss=Math.max(0,wB-wA);if(uci===best)loss=0;
    let cls=loss<=0.5?'best':loss<2?'excellent':loss<5?'good':loss<10?'inaccuracy':loss<20?'mistake':'blunder';
    if(prevLoss>=12&&loss>=8&&loss<25)cls='miss';
    if(inBook(i)&&loss<3)cls='book';
    else if(cls==='best'||cls==='excellent'){
      const prev=hv[i-1],recap=prev&&m.captured&&prev.to===m.to;
      if(loss<=3&&wA>=40&&wB<92&&isSac(fens[i],uci))cls='brilliant';
      else if(cls==='best'&&r0.alt&&wB-winPct(r0.alt.cp)>=15&&wB<95&&!recap)cls='great';
    }
    M.push({i,san:m.san,uci,color:m.color,piece:m.piece,cls,loss,wB,wA,best,bestSan:pvSans(fens[i],[best],1)[0]||m.san});
    prevLoss=loss;
  });
  const avg=a=>a.length?Math.round(a.reduce((x,y)=>x+y,0)/a.length*10)/10:0;
  const ac={w:[],b:[]},cnt={w:{},b:{}},ph={w:{o:[],m:[],e:[]},b:{o:[],m:[],e:[]}};
  M.forEach(x=>{const a=accOf(x.loss);ac[x.color].push(a);cnt[x.color][x.cls]=(cnt[x.color][x.cls]||0)+1;
    const pcs=fens[x.i].split(' ')[0].replace(/[^a-zA-Z]/g,'').length;ph[x.color][x.i<20?'o':pcs<=12?'e':'m'].push(a)});
  let swings=0,last=0;for(let k=0;k<fens.length;k++){const s=cpW(k)>120?1:cpW(k)<-120?-1:0;if(s&&last&&s!==last)swings++;if(s)last=s}
  return{fens,M,res,me,hd:P.hd,cpW,opening:openName,accW:avg(ac.w),accB:avg(ac.b),estW:estElo(avg(ac.w),ac.w.length),estB:estElo(avg(ac.b),ac.b.length),cnt,ph:{w:{o:avg(ph.w.o),m:avg(ph.w.m),e:avg(ph.w.e)},b:{o:avg(ph.b.o),m:avg(ph.b.m),e:avg(ph.b.e)}},swings,
    keys:M.filter(x=>['brilliant','great','blunder','mistake','miss'].indexOf(x.cls)>=0).map(x=>x.i)}}

// ---------- Brilliant Trainer ----------
const who=(A,x)=>A.me?(x.color===A.me?'You':'Your opponent'):(x.color==='w'?'White':'Black');
const evTxt=cp=>Math.abs(cp)>=9000?(cp>0?'+':'-')+'M'+Math.round((10000-Math.abs(cp))/10):(cp>=0?'+':'')+(cp/100).toFixed(2);
function evDesc(cp){const a=Math.abs(cp),s=cp>0?'White':'Black';return a<30?'The position is balanced.':a<100?s+' is slightly better.':a<250?s+' has a clear advantage.':a<600?s+' is winning.':s+' is completely winning.'}
function consequence(A,i){const f1=A.fens[i+1],r1=A.res[i+1],L=n=>pvSans(f1,r1.pv,n).join(' ');
  if(r1.mate>0)return`it allows a forced checkmate in ${r1.mate}: <i>${L(r1.mate*2-1)}</i>`;
  const wc=winningCaptures(f1)[0];
  if(wc)return`it leaves the ${PN[wc.m.captured]} on ${wc.m.to} exposed, and ${wc.m.san} wins material`;
  const d=pvMatDelta(f1,r1.pv,4);
  if(d>=2)return`after <i>${L(4)}</i> the material ends ${d} ${Q(d)} down`;
  return`the evaluation swings from ${evTxt(A.cpW(i))} to ${evTxt(A.cpW(i+1))}, and ${pvSans(f1,r1.pv,1)[0]||'the reply'} hands over the initiative`}
function whyBest(A,i){const x=A.M[i],f0=A.fens[i],r0=A.res[i],o=[];
  if(r0.mate>0)o.push(`leads to a forced mate in ${r0.mate}`);
  motifs(f0,x.best).forEach(m=>o.push(m));
  const d=pvMatDelta(f0,r0.pv,4);if(d>=1)o.push(`wins ${d} ${Q(d)} of material by force`);
  const th=winningCaptures(flipTurn(f0))[0];if(th)o.push(`stops the threat of ${th.m.san}`);
  if(!o.length)o.push(x.i<20?'follows opening principles: develop, fight for the center, castle':`keeps the evaluation at ${evTxt(A.cpW(i))}`);
  return o.join(', ')}
function tags(ms){const t=[];ms.forEach(m=>{if(/fork/.test(m))t.push('Fork');if(/sacrific/.test(m))t.push('Sacrifice');if(/mate/.test(m))t.push('Mating attack');if(/gives check/.test(m))t.push('Check');if(/captures/.test(m))t.push('Capture');if(/promot/.test(m))t.push('Promotion')});return t.filter((v,i)=>t.indexOf(v)===i)}
function coach(A,i){
  const x=A.M[i],W=who(A,x),f0=A.fens[i],f1=A.fens[i+1],r0=A.res[i],r1=A.res[i+1],cl=CLS[x.cls],mt=motifs(f0,x.uci),P=[];
  const th=winningCaptures(flipTurn(f0))[0],opp=A.me&&x.color===A.me?'Your opponent':'The opponent';
  if(th&&x.cls!=='brilliant')P.push(`⚠ Before this move, ${opp.toLowerCase()} was threatening <b>${th.m.san}</b>.`);
  switch(x.cls){
    case'brilliant':P.unshift(`${W} found a <b>brilliant</b> move! ${x.san} ${mt.join(' and ')||'is a deep, hard-to-see idea'}. It looks risky, but Stockfish confirms it works. If it is accepted, play continues <i>${pvSans(f1,r1.pv,5).join(' ')}</i>.`);break;
    case'great':P.unshift(`<b>Great find!</b> ${x.san} is the only move that holds everything together. The next best option would cost about ${Math.round(x.wB-winPct(r0.alt.cp))}% of the win chance.`);break;
    case'best':P.unshift(`${x.san} is the engine's top choice${mt.length?': it '+mt.join(', '):''}. The idea continues with <i>${pvSans(f0,r0.pv,5).join(' ')}</i>.`);break;
    case'book':P.unshift(`${x.san} is a standard opening move${A.opening?' in the <b>'+A.opening+'</b>':''}. Develop pieces, fight for the center and castle early.`);break;
    case'excellent':case'good':P.unshift(`${x.san} is ${x.cls}. Stockfish slightly prefers <b>${x.bestSan}</b> (it ${whyBest(A,i)}), but the difference is small.`);break;
    default:{
      if(x.cls==='miss'&&i>0)P.unshift(`${who(A,A.M[i-1])}'s last move was a mistake and ${W.toLowerCase()==='you'?'you':W} did not punish it.`);
      P.push(`<b>${x.san} is a ${x.cls}.</b> ${cap(consequence(A,i))} (win chance ${Math.round(x.wB)}% → ${Math.round(x.wA)}%).`);
      P.push(`<b>Better was ${x.bestSan}.</b> It ${whyBest(A,i)}. Main line: <i>${pvSans(f0,r0.pv,6).join(' ')}</i>.`);
      const tg=tags(motifs(f0,x.best));if(tg.length)P.push(`🏷 Missed idea: ${tg.join(' · ')}.`);}}
  const tg2=tags(mt);
  return`<div class="ct"><span class="bdg2" style="background:${cl[1]}">${cl[0]}</span> ${x.san} · ${cl[2]}</div>`+P.map(p=>`<p>${p}</p>`).join('')+
    `<div class="fight">⚔ ${evDesc(A.cpW(i+1))} (${evTxt(A.cpW(i+1))})${tg2.length&&x.cls!=='miss'?' · 🏷 '+tg2.join(' · '):''}</div>`}
function summaryHtml(A){
  const me=A.me,cw=A.cnt.w,cb=A.cnt.b,c=me?A.cnt[me]:null,P=[];
  P.push(`Hi, I'm <b>Brilliant Trainer</b>. I went through every move with Stockfish.${A.opening?' The game opened as the <b>'+A.opening+'</b>.':''}`);
  P.push(`Accuracy: White <b>${A.accW}%</b>, Black <b>${A.accB}%</b>. Estimated Elo: White <b>${A.estW||'—'}</b>, Black <b>${A.estB||'—'}</b>. The advantage swung ${A.swings} time${A.swings===1?'':'s'}, so ${A.swings>2?'this was a real fight':A.swings?'there was a turning point':'one side stayed in control'}.`);
  const big=A.M.slice().sort((a,b)=>b.loss-a.loss).filter(x=>x.loss>=10&&(!me||x.color===me)).slice(0,3);
  if(big.length)P.push(`Critical moments${me?' for you':''}: `+big.map(x=>`move ${Math.floor(x.i/2)+1}${x.color==='w'?'':'…'} <b>${x.san}</b> (−${Math.round(x.loss)}%)`).join(', ')+'. Tap ⏩ to jump through them.');
  const br=A.M.filter(x=>x.cls==='brilliant');if(br.length)P.push(`✨ ${br.length} brilliant move${br.length>1?'s':''}: ${br.map(x=>x.san).join(', ')}!`);
  if(c){const bl=c.blunder||0,mi=(c.mistake||0)+(c.miss||0);const ph=A.ph[me],names={o:'opening',m:'middlegame',e:'endgame'};
    const weak=Object.keys(ph).filter(k=>ph[k]>0).sort((a,b)=>ph[a]-ph[b])[0];
    P.push(bl?`You made ${bl} blunder${bl>1?'s':''}. Before each move ask: <i>what does this leave hanging, and what is my opponent threatening?</i>`:mi?`No blunders, but ${mi} mistake${mi>1?'s':''}. Slow down in critical positions and check checks, captures and threats.`:'Very clean game. Keep calculating the same way.');
    if(weak)P.push(`Your weakest phase was the <b>${names[weak]}</b> (${ph[weak]}% accuracy).`)}
  return`<div class="ct">Game summary</div>`+P.map(p=>`<p>${p}</p>`).join('')}
