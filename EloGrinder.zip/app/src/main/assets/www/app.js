// ===== state =====
const $=s=>document.querySelector(s),app=$('#app');
const defaults=()=>({user:null,ratings:{},games:[],names:[],lang:'en',theme:'green'});
function loadS(){try{return Object.assign(defaults(),JSON.parse(localStorage.getItem('elogrinder')||'{}'))}catch(e){return defaults()}}
let S=loadS(),LANG=S.lang;
function saveS(){try{localStorage.setItem('elogrinder',JSON.stringify(S))}catch(e){toast('Storage full')}}
const t=k=>(I[LANG]&&I[LANG][k])||I.en[k]||k;
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const toast=m=>{try{Android.toast(m)}catch(e){alert(m)}};
const THEMES={green:['#eeeed2','#769656'],brown:['#f0d9b5','#b58863'],blue:['#dee3e6','#8ca2ad'],purple:['#f0f1f0','#8475b9'],gray:['#e4e4e4','#7b8794'],wood:['#e8c99b','#a9703f'],ice:['#e8f1f7','#6b9ac4'],coral:['#f6e3d5','#d6845c']};
function applyTheme(){const[l,d]=THEMES[S.theme]||THEMES.green,r=document.documentElement;r.style.setProperty('--l',l);r.style.setProperty('--d',d);r.dir=LANG==='ar'?'rtl':'ltr'}
const ICON={bullet:'⚡',blitz:'🔥',rapid:'⏱️',unlimited:'♾️',imported:'📥'};
// chess.com time controls (base seconds, increment, label)
const TC={bullet:[[60,0,'1 min'],[60,1,'1 | 1'],[120,1,'2 | 1']],blitz:[[180,0,'3 min'],[180,2,'3 | 2'],[300,0,'5 min']],rapid:[[600,0,'10 min'],[900,10,'15 | 10'],[1800,0,'30 min']],unlimited:[[0,0,'∞']]};
const THINK={bullet:[.15,.6],blitz:[.4,1.6],rapid:[.7,2.8],unlimited:[.6,1.8]};

// ===== Glicko (same system chess.com uses) =====
function glicko(r,rd,or,ord,s){const q=Math.LN10/400,g=x=>1/Math.sqrt(1+3*q*q*x*x/(Math.PI*Math.PI)),gg=g(ord),E=1/(1+Math.pow(10,-gg*(r-or)/400)),d2=1/(q*q*gg*gg*E*(1-E)),den=1/(rd*rd)+1/d2;return[r+q/den*gg*(s-E),Math.max(45,Math.sqrt(1/den))]}

// ===== navigation =====
let cur=null,stack=[];
function show(fn,...a){if(cur)stack.push(cur);cur=[fn,a];fn(...a)}
function swap(fn,...a){cur=[fn,a];fn(...a)}
function back(){const p=stack.pop();if(p){cur=p;p[0](...p[1]);return true}return false}
window.handleBack=()=>{if($('#modal').innerHTML){closeModal();return true}
  if(cur&&cur[0]===GameView&&G&&!G.over){confirmResign();return true}
  if(cur&&cur[0]===Review){ANTOK++;stopLine()}
  return back()};
const hdr=ti=>`<div class="hdr"><button data-a="back">‹</button><span>${ti}</span></div>`;
function modal(h){$('#modal').innerHTML=`<div class="mb">${h}</div>`}
function closeModal(){$('#modal').innerHTML=''}
const ACT={};
document.addEventListener('click',e=>{const a=e.target.closest('[data-a]');if(a&&ACT[a.dataset.a])ACT[a.dataset.a](a.dataset.p,a,e)});
ACT.back=()=>{if(cur&&cur[0]===GameView&&G&&!G.over)return confirmResign();if(cur&&cur[0]===Review){ANTOK++;stopLine()}back()};
ACT.close=closeModal;ACT.home=()=>{closeModal();stack=[];swap(Home)};

// ===== screens =====
function Home(){applyTheme();app.innerHTML=`<div class="home"><div class="logo">♞</div><h1>Elo Grinder</h1><p>${t('tagline')}</p>
<button class="big g" data-a="go" data-p="grind">♟ ${t('grind')}</button>
<button class="big" data-a="go" data-p="analyzer">🔍 ${t('analyzer')}</button>
<button class="big" data-a="go" data-p="settings">⚙️ ${t('settings')}</button></div>`}
ACT.go=p=>show({grind:Grind,analyzer:Analyzer,settings:Settings}[p]);

function Grind(){
  if(!S.user)return nameScreen();
  app.innerHTML=hdr(t('grind'))+`<div class="pad"><div class="who">👤 ${esc(S.user)}</div>`+['bullet','blitz','rapid','unlimited'].map(f=>{const r=S.ratings[f];
    return`<div class="card fmt" data-a="fmt" data-p="${f}"><span class="ic">${ICON[f]}</span><div><b>${t(f)}</b><small>${r?`${r.w+r.d+r.l} ${t('games')} · W${r.w} D${r.d} L${r.l}`:t('notStarted')}</small></div><div class="rt">${r?Math.round(r.r):'—'}</div></div>`}).join('')+'</div>'}
ACT.fmt=f=>show(Format,f);
function nameScreen(){app.innerHTML=hdr(t('grind'))+`<div class="pad"><h3>${t('username')}</h3><input id="nm" maxlength="16" autocomplete="off"><button class="btn g" data-a="saveName" style="margin-top:14px">${t('start')}</button></div>`}
ACT.saveName=()=>{const v=$('#nm').value.trim();if(!v)return;S.user=v;saveS();swap(Grind)};
const tcGrid=f=>`<div class="tcs">${TC[f].map((x,i)=>`<button class="tc" data-a="startGrind" data-p="${f}:${i}">${x[2]}</button>`).join('')}</div>`;
function Format(f){const r=S.ratings[f];let h=hdr(ICON[f]+' '+t(f))+'<div class="pad">';
  if(r)h+=`<div class="card stat"><div class="big">${Math.round(r.r)}</div><small class="small">Peak ${Math.round(r.peak)} · W${r.w} D${r.d} L${r.l}</small></div><h3>${t('continue')}</h3>${tcGrid(f)}<button class="btn red" data-a="resetFmt" data-p="${f}">${t('reset')}</button>`;
  else h+=`<h3>${t('startElo')}</h3><div class="chips">${[400,800,1200].map(e=>`<span class="chip${e===800?' on':''}" data-a="pickElo" data-e="${e}">${e}</span>`).join('')}</div><h3>${t('chooseTime')}</h3>${tcGrid(f)}`;
  app.innerHTML=h+'</div>'}
ACT.pickElo=(p,el)=>{document.querySelectorAll('.chip').forEach(c=>c.classList.remove('on'));el.classList.add('on')};
ACT.resetFmt=f=>modal(`<h2>${t('reset')}</h2><p>${t('resetQ')}</p><button class="btn red" data-a="doReset" data-p="${f}">${t('reset')}</button><button class="btn" data-a="close">${t('cancel')}</button>`);
ACT.doReset=f=>{delete S.ratings[f];saveS();closeModal();Format(f)};
ACT.startGrind=p=>{const[f,i]=p.split(':');if(!S.ratings[f]){const c=document.querySelector('.chip.on'),e=c?+c.dataset.e:800;S.ratings[f]={r:e,rd:250,peak:e,w:0,d:0,l:0,start:e}}saveS();newGame(f,+i,true)};

// ===== bots =====
const NA=['Shadow','Iron','Silent','Rapid','Crimson','Lunar','Frost','Neon','Wild','Quiet','Turbo','Royal','Mystic','Sneaky','Golden','Dark','Cosmic','Lucky','Salty','Brave'],NB=['Knight','Rook','Pawn','Bishop','Fox','Wolf','Hawk','Panda','Tiger','Dragon','Owl','Gambit','Castle','Viper','Falcon','Otter'],FLAGS=['🇺🇸','🇬🇧','🇮🇳','🇧🇷','🇩🇪','🇫🇷','🇪🇸','🇷🇺','🇹🇷','🇯🇵','🇨🇳','🇵🇱','🇮🇹','🇲🇽','🇳🇬','🇨🇦','🇦🇺','🇳🇱'];
const pick=a=>a[Math.floor(Math.random()*a.length)],gauss=()=>(Math.random()+Math.random()+Math.random()-1.5)/.5;
function botName(){let n,k=0;do{n=pick(NA)+pick(NB)+(Math.random()<.75?Math.floor(Math.random()*9999):'');k++}while(S.names.indexOf(n)>=0&&k<50);S.names.push(n);if(S.names.length>800)S.names.shift();return n}

// ===== game =====
let G=null;
function newGame(f,i,first){const R=S.ratings[f],tc=TC[f][i],color=Math.random()<.5?'w':'b';
  const bot={name:botName(),elo:Math.max(100,Math.round(R.r+gauss()*70)),flag:pick(FLAGS)};
  clearInterval(G&&G.iv);
  G={f,i,tc,base:tc[0],inc:tc[1],clk:{w:tc[0],b:tc[0]},chess:new Chess(),color,bot,sel:null,tg:[],over:false,ply:0,last:null,flip:color==='b',busy:false,id:Date.now(),t:performance.now()};
  saveS();(first?show:swap)(GameView)}
const fmtClk=s=>{if(s<=0)return'0:00';if(s<10)return s.toFixed(1);return Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0')};
function GameView(){const g=G,top=g.color==='w'?'b':'w';
  app.innerHTML=`<div class="game"><div class="gtop"><button class="ib" data-a="back">‹</button><span>${ICON[g.f]} ${t(g.f)} · ${g.tc[2]}</span><span class="rt" style="font-size:18px">${Math.round(S.ratings[g.f].r)}</span></div>
<div class="ms" id="ms"></div>
<div class="pbar"><div class="av">${g.bot.flag}</div><div><b>${esc(g.bot.name)}</b> <span class="small">(${g.bot.elo})</span><div class="small" id="st"></div></div><div class="clk" id="ck-${top}"></div></div>
<div class="board" id="bd"></div>
<div class="pbar"><div class="av">😎</div><div><b>${esc(S.user)}</b> <span class="small">(${Math.round(S.ratings[g.f].r)})</span></div><div class="clk" id="ck-${g.color}"></div></div>
<div class="gb"><button data-a="offerDraw">½ ${t('draw')}</button><button data-a="resign">⚑ ${t('resign')}</button><button data-a="flip">⟲</button></div></div>`;
  drawGame();clearInterval(g.iv);if(g.over)return;g.iv=setInterval(tick,100);
  if(g.chess.turn()!==g.color)botTurn()}
function drawGame(){const g=G;if(!g||!$('#bd'))return;
  renderBoard($('#bd'),g.chess.fen(),{flip:g.flip,sel:g.sel,tg:g.tg,last:g.last,pre:g.pre?[g.pre.from,g.pre.to]:null,tap:tapSq});
  const h=g.chess.history();$('#ms').innerHTML=h.map((m,i)=>(i%2?'':`<b>${i/2+1}.</b>`)+`<span class="${i===h.length-1?'cur':''}">${m}</span> `).join('');$('#ms').scrollLeft=1e5;
  ['w','b'].forEach(c=>{const e=$('#ck-'+c);if(e){e.textContent=g.base?fmtClk(g.clk[c]):'∞';e.classList.toggle('on',!g.over&&g.chess.turn()===c&&g.ply>=2);e.classList.toggle('low',g.base&&g.clk[c]<20)}})}
function tick(){const g=G;if(!g||g.over||!g.base)return;const now=performance.now(),dt=(now-g.t)/1000;g.t=now;if(g.ply<2)return;
  const c=g.chess.turn();g.clk[c]=Math.max(0,g.clk[c]-dt);const e=$('#ck-'+c);if(e){e.textContent=fmtClk(g.clk[c]);e.classList.toggle('low',g.clk[c]<20)}
  if(g.clk[c]<=0)timeoutEnd(c)}
// FIDE/chess.com: flagging only wins if the opponent could still deliver mate with some sequence of legal moves
function canMate(ch,color){let minors=0,other=0,opp=0;ch.board().forEach(r=>r.forEach(p=>{if(!p)return;if(p.color===color){if(p.type==='p'||p.type==='r'||p.type==='q')other++;else if(p.type!=='k')minors++}else if(p.type!=='k')opp++}));return other>0||minors>=2||(minors===1&&opp>0)}
function timeoutEnd(c){const g=G,winner=c==='w'?'b':'w';if(!canMate(g.chess,winner))return endGame('draw','timeout vs insufficient material');endGame(c===g.color?'loss':'win','timeout')}
function preTap(sq,p){const g=G;
  if(g.sel&&g.tg.indexOf(sq)>=0){g.pre={from:g.sel,to:sq};g.sel=null;g.tg=[];return drawGame()}
  if(p&&p.color===g.color){g.sel=sq;g.tg=[];try{g.tg=new Chess(flipTurn(g.chess.fen())).moves({square:sq,verbose:true}).map(m=>m.to)}catch(e){}}
  else{g.sel=null;g.tg=[];g.pre=null}
  drawGame()}
function tapSq(sq){const g=G;if(!g||g.over)return;const p=g.chess.get(sq);
  if(g.busy||g.chess.turn()!==g.color)return preTap(sq,p);
  if(g.sel){const mv=g.chess.moves({square:g.sel,verbose:true}).filter(m=>m.to===sq);
    if(mv.length){if(mv[0].promotion)return askPromo(g.sel,sq);return doMove({from:g.sel,to:sq})}}
  if(p&&p.color===g.color){g.sel=sq;g.tg=g.chess.moves({square:sq,verbose:true}).map(m=>m.to)}else{g.sel=null;g.tg=[]}
  drawGame()}
function askPromo(a,b){modal(`<div class="promo">${['q','r','b','n'].map(p=>`<button data-a="promo" data-p="${a}${b}${p}">${GL[p]}\uFE0E</button>`).join('')}</div>`)}
ACT.promo=p=>{closeModal();doMove({from:p.slice(0,2),to:p.slice(2,4),promotion:p[4]})};
function doMove(m){const g=G,mv=g.chess.move(m);if(!mv)return;g.sel=null;g.tg=[];g.last=[mv.from,mv.to];
  if(g.ply>=2&&g.base)g.clk[mv.color]+=g.inc;g.ply++;g.t=performance.now();drawGame();
  if(checkEnd())return;
  if(g.chess.turn()!==g.color){botTurn();return}
  if(g.pre){const p=g.pre;g.pre=null;const m=g.chess.moves({verbose:true}).find(x=>x.from===p.from&&x.to===p.to);
    if(m){doMove({from:p.from,to:p.to,promotion:m.promotion?'q':undefined});return}drawGame()}}
function checkEnd(){const c=G.chess;
  if(c.in_checkmate()){endGame(c.turn()===G.color?'loss':'win','checkmate');return true}
  if(c.in_stalemate()){endGame('draw','stalemate');return true}
  if(c.insufficient_material()){endGame('draw','insufficient material');return true}
  if(c.in_threefold_repetition()){endGame('draw','repetition');return true}
  if(c.in_draw()){endGame('draw','50-move rule');return true}return false}
async function botTurn(){const g=G;g.busy=true;const s=$('#st');if(s)s.textContent=t('thinking');const t0=performance.now();
  const m=await botPick(g.chess,g.bot.elo);let[a,b]=THINK[g.f];let want=(a+Math.random()*(b-a))*1000;if(g.base)want=Math.min(want,g.clk[g.color==='w'?'b':'w']*60);
  const el=performance.now()-t0;if(el<want)await sleep(want-el);
  if(G!==g||g.over)return;g.busy=false;const s2=$('#st');if(s2)s2.textContent='';if(m)doMove({from:m.from,to:m.to,promotion:m.promotion})}
ACT.flip=()=>{if(G){G.flip=!G.flip;drawGame()}};
ACT.offerDraw=()=>{const g=G;if(!g||g.over)return;if(g.ply>=30&&Math.abs(matOf(g.chess))<=1&&Math.random()<.6)endGame('draw','agreement');else toast(t('declined'))};
ACT.resign=()=>confirmResign();
function confirmResign(){if(!G||G.over)return back();modal(`<h2>${t('resign')}</h2><p>${t('resignQ')}</p><button class="btn red" data-a="doResign">${t('resign')}</button><button class="btn" data-a="close">${t('cancel')}</button>`)}
ACT.doResign=()=>{closeModal();endGame('loss','resignation')};
function endGame(res,why){const g=G;if(!g||g.over)return;g.over=true;g.pre=null;clearInterval(g.iv);g.busy=false;
  const R=S.ratings[g.f],s=res==='win'?1:res==='draw'?.5:0,before=R.r,[nr,nrd]=glicko(R.r,R.rd,g.bot.elo,50,s);
  R.r=Math.max(100,nr);R.rd=nrd;R.peak=Math.max(R.peak,R.r);R[res==='win'?'w':res==='loss'?'l':'d']++;
  const c=g.chess,wn=g.color==='w'?S.user:g.bot.name,bn=g.color==='w'?g.bot.name:S.user,pr=res==='draw'?'1/2-1/2':(res==='win')===(g.color==='w')?'1-0':'0-1';
  const d=new Date(),ds=d.getFullYear()+'.'+String(d.getMonth()+1).padStart(2,'0')+'.'+String(d.getDate()).padStart(2,'0');
  c.header('Event','Elo Grinder '+t(g.f),'Site','Offline','Date',ds,'White',wn,'Black',bn,'Result',pr,'WhiteElo',String(g.color==='w'?Math.round(before):g.bot.elo),'BlackElo',String(g.color==='b'?Math.round(before):g.bot.elo),'TimeControl',g.base?g.base+(g.inc?'+'+g.inc:''):'-');
  g.rec={id:g.id,date:Date.now(),f:g.f,tc:g.tc[2],me:g.color,bot:{name:g.bot.name,elo:g.bot.elo},res,why,pgn:c.pgn(),rb:Math.round(before),ra:Math.round(R.r),title:wn+' vs '+bn};
  S.games.push(g.rec);saveS();drawGame();
  const dl=g.rec.ra-g.rec.rb;
  setTimeout(()=>modal(`<h2>${res==='win'?'🏆 '+t('win'):res==='loss'?t('loss'):t('drawn')}</h2><div class="small">${why}</div><div class="delta ${dl>=0?'pos':'neg'}">${dl>=0?'+':''}${dl}</div><div class="small">${t(g.f)}: ${g.rec.rb} → ${g.rec.ra}</div><br>
<button class="btn g" data-a="reviewLast">🔍 ${t('review')}</button><button class="btn" data-a="again">${t('rematch')} (${g.tc[2]})</button><button class="btn" data-a="home">${t('home')}</button>`),600)}
ACT.reviewLast=()=>{closeModal();show(Review,G.rec)};
ACT.again=()=>{closeModal();newGame(G.f,G.i)};

// ===== board rendering (shared) =====
const GL={p:'♟',n:'♞',b:'♝',r:'♜',q:'♛',k:'♚'};
function renderBoard(el,fen,o){o=o||{};const ch=new Chess(fen);let ks=null;
  if(ch.in_check()){ch.board().forEach((r,ri)=>r.forEach((p,fi)=>{if(p&&p.type==='k'&&p.color===ch.turn())ks='abcdefgh'[fi]+(8-ri)}))}
  let h='';for(let r=0;r<8;r++)for(let f=0;f<8;f++){const rk=o.flip?r:7-r,fl=o.flip?7-f:f,sq='abcdefgh'[fl]+(rk+1),p=ch.get(sq);
    let c='sq '+((fl+rk)%2?'l':'d');if(o.last&&(sq===o.last[0]||sq===o.last[1]))c+=' lm';if(sq===o.sel)c+=' sel';if(o.pre&&(sq===o.pre[0]||sq===o.pre[1]))c+=' pm';if(sq===ks)c+=' chk';
    if(o.tg&&o.tg.indexOf(sq)>=0)c+=p?' tgc':' tg';
    h+=`<div class="${c}" data-s="${sq}">${f===0?`<span class="co r">${rk+1}</span>`:''}${r===7?`<span class="co f">${'abcdefgh'[fl]}</span>`:''}${p?`<span class="pc ${p.color}">${GL[p.type]}\uFE0E</span>`:''}${o.badge&&o.badge.sq===sq?`<i class="bdgsq" style="background:${CLS[o.badge.cls][1]}">${CLS[o.badge.cls][0]}</i>`:''}</div>`}
  if(o.arrows&&o.arrows.length){const C=s=>{const f='abcdefgh'.indexOf(s[0]),r=+s[1]-1;return[(o.flip?7-f:f)+.5,(o.flip?r:7-r)+.5]};
    h+=`<svg class="arrows" viewBox="0 0 8 8">`+o.arrows.map(a=>{const[x1,y1]=C(a[0]),[x2,y2]=C(a[1]),g=Math.atan2(y2-y1,x2-x1),ex=x2-Math.cos(g)*.28,ey=y2-Math.sin(g)*.28,sx=Math.sin(g)*.2,sy=Math.cos(g)*.2;
      return`<line x1="${x1}" y1="${y1}" x2="${ex}" y2="${ey}" stroke="${a[2]}" stroke-width=".17" stroke-linecap="round"/><polygon fill="${a[2]}" points="${x2},${y2} ${ex-sx},${ey+sy} ${ex+sx},${ey-sy}"/>`}).join('')+'</svg>'}
  el.innerHTML=h;el.onclick=e=>{const s=e.target.closest('[data-s]');if(s&&o.tap)o.tap(s.dataset.s)}}

// ===== analyzer / history / import =====
let hf='all';
function Analyzer(){const gs=S.games.slice().reverse().filter(g=>hf==='all'||g.f===hf);
  app.innerHTML=hdr(t('analyzer'))+`<div class="pad"><button class="btn g" data-a="importPgn">📥 ${t('importPgn')}</button>
<h3>${t('history')}</h3><div class="chips">${['all','bullet','blitz','rapid','unlimited','imported'].map(f=>`<span class="chip${hf===f?' on':''}" data-a="filt" data-p="${f}">${f==='all'?t('all'):ICON[f]+' '+(f==='imported'?t('imported'):t(f))}</span>`).join('')}</div>
${gs.length?gs.map(g=>{const dl=g.ra!=null?g.ra-g.rb:null,c=g.res==='win'?'pos':g.res==='loss'?'neg':'';
  return`<div class="card gcard" data-a="openG" data-p="${g.id}"><span class="res ${c}">${g.res==='win'?'W':g.res==='loss'?'L':g.res==='draw'?'D':'•'}</span><div><b>${esc(g.title)}</b><small>${ICON[g.f]} ${g.f==='imported'?t('imported'):t(g.f)} · ${g.tc||''} · ${new Date(g.date).toLocaleDateString()}</small></div><div class="rt ${dl>=0?'pos':'neg'}" style="font-size:16px">${dl==null?'':(dl>=0?'+':'')+dl}</div><button class="ib" data-a="delG" data-p="${g.id}" style="width:32px;height:32px;font-size:15px">✕</button></div>`}).join(''):`<p class="small">${t('noGames')}</p>`}</div>`}
ACT.filt=f=>{hf=f;Analyzer()};
ACT.openG=id=>{const g=S.games.find(x=>String(x.id)===id);if(g)show(Review,g)};
ACT.delG=(id,el,e)=>{e.stopPropagation();S.games=S.games.filter(x=>String(x.id)!==id);saveS();Analyzer()};
ACT.importPgn=()=>modal(`<h2>${t('importPgn')}</h2><textarea id="pgn" placeholder="${t('paste')}"></textarea><button class="btn g" data-a="doImport">${t('importPgn')}</button><button class="btn" data-a="pickPgn">📂 ${t('file')}</button><button class="btn" data-a="close">${t('cancel')}</button>`);
ACT.pickPgn=()=>{try{Android.pickFile('pgn')}catch(e){toast('Not available')}};
ACT.doImport=()=>importPgn($('#pgn').value);
function importPgn(text){const parts=text.split(/\n\s*\n(?=\[Event )/).map(s=>s.trim()).filter(Boolean);let n=0,last=null;
  parts.forEach(p=>{const c=new Chess();if(c.load_pgn(p,{sloppy:true})&&c.history().length){const h=c.header(),g={id:Date.now()+n,date:Date.now(),f:'imported',tc:h.TimeControl||'',me:null,res:null,pgn:p,title:(h.White||'White')+' vs '+(h.Black||'Black')};S.games.push(g);last=g;n++}});
  if(!n)return toast(t('bad'));saveS();closeModal();if(n===1)show(Review,last);else{hf='imported';Analyzer()}}
window.onFilePicked=(k,text)=>{if(k==='pgn')importPgn(text);else if(k==='backup')restore(text)};
window.onFileSaved=()=>toast(t('saved'));

// ===== game review (chess.com-style) with Brilliant Trainer =====
let R=null,ANTOK=0;
async function Review(g){const tok=++ANTOK;
  app.innerHTML=hdr(esc(g.title))+`<div class="coachbox"><span class="bt">🧠</span><div class="bub"><div class="nm">Brilliant Trainer</div>${t('analyzing')}<div class="pbw"><div id="pb"></div></div></div></div>`;
  if(!g.an){const res=await analyzeGame(g.pgn,p=>{if(tok===ANTOK&&$('#pb'))$('#pb').style.width=p*100+'%'},()=>tok!==ANTOK);if(tok!==ANTOK)return;if(!res){app.innerHTML=hdr(esc(g.title))+`<div class="pad"><p>${t('bad')}</p></div>`;return}g.an=res;saveS()}
  const A=build(g.pgn,g.an,g.me||null);R={g,A,k:0,flip:g.me==='b',arrow:true,pv:null,retry:null};drawReview()}
function drawReview(){const A=R.A,top=R.flip?'w':'b',bot=top==='w'?'b':'w',nm=c=>esc(A.hd[c==='w'?'White':'Black']||(c==='w'?'White':'Black')),ac=c=>c==='w'?A.accW:A.accB;
  app.innerHTML=hdr(esc(R.g.title))+`<div class="rv"><div class="coachbox"><span class="bt">🧠</span><div class="bub"><div class="nm">Brilliant Trainer</div><div id="cb"></div></div></div><div class="prow"><span>${top==='w'?'⬜':'⬛'} ${nm(top)}</span><span>${t('accuracy')} ${ac(top)}%</span></div>
<div class="brow"><div class="evb"><div id="evf"></div></div><div class="board" id="bd"></div></div>
<div class="prow"><span>${bot==='w'?'⬜':'⬛'} ${nm(bot)}</span><span>${t('accuracy')} ${ac(bot)}%</span></div>
<div class="ctr"><button data-a="rk" data-p="start">⏮</button><button data-a="rk" data-p="prev">‹</button><button id="pl" data-a="play">▶</button><button data-a="rk" data-p="next">›</button><button data-a="rk" data-p="end">⏭</button><button data-a="keyNext">⏩</button><button data-a="arrowTog">💡</button></div>
<div class="stats">${statsHtml(A)}</div><svg class="gr" id="gr" viewBox="0 0 300 60" preserveAspectRatio="none" data-a="graph"></svg>
<div class="ml" id="ml"></div></div>`;
  const n=A.M.length;let pts='0,60 ',mid=30;for(let k=0;k<=n;k++)pts+=`${(k/Math.max(1,n))*300},${60-winPct(A.cpW(k))*.6} `;pts+='300,60';
  $('#gr').innerHTML=`<polygon points="${pts}" fill="#e8e8e8"/><line x1="0" y1="30" x2="300" y2="30" stroke="#777" stroke-width=".5"/><line id="gk" x1="0" y1="0" x2="0" y2="60" stroke="#81b64c" stroke-width="1.5"/>`;
  $('#ml').innerHTML=A.M.map(x=>`${x.i%2?'':`<span class="mn">${x.i/2+1}.</span>`}<span class="mv" data-a="rk" data-p="k${x.i+1}" id="m${x.i+1}">${x.san}<i style="color:${CLS[x.cls][1]}">${CLS[x.cls][0]}</i></span>`).join('');
  showPos()}
function statsHtml(A){const rows=['brilliant','great','best','excellent','good','book','inaccuracy','mistake','miss','blunder'],nm=c=>esc(A.hd[c==='w'?'White':'Black']||(c==='w'?'White':'Black'));
  return`<table class="stt"><tr><th></th><th>⬜ ${nm('w')}</th><th>⬛ ${nm('b')}</th></tr><tr><td><b>Est. Elo</b></td><td><b>${A.estW||'—'}</b></td><td><b>${A.estB||'—'}</b></td></tr><tr><td>${t('accuracy')}</td><td>${A.accW}%</td><td>${A.accB}%</td></tr>`+rows.map(r=>`<tr><td><span class="bdg2" style="background:${CLS[r][1]}">${CLS[r][0]}</span> ${CLS[r][2]}</td><td>${A.cnt.w[r]||0}</td><td>${A.cnt.b[r]||0}</td></tr>`).join('')+`</table><p class="small">Estimated Elo is a rough guess from accuracy.</p>`}
function showPos(){const A=R.A,k=R.k,x=k?A.M[k-1]:null,arrows=[];
  if(x&&R.arrow&&x.uci!==x.best&&['inaccuracy','mistake','miss','blunder'].indexOf(x.cls)>=0)arrows.push([x.best.slice(0,2),x.best.slice(2,4),'#81b64c']);
  if(R.retry){drawRetry();return}
  renderBoard($('#bd'),A.fens[k],{flip:R.flip,last:x?[x.uci.slice(0,2),x.uci.slice(2,4)]:null,arrows,badge:x?{sq:x.uci.slice(2,4),cls:x.cls}:null});
  evBar(A.fens[k],k);
  $('#cb').innerHTML=k?coach(A,k-1)+`<div class="acts"><button data-a="line" data-p="best">▶ Best line</button><button data-a="line" data-p="after">▶ After this move</button><button data-a="tryIt">↻ Try the best move</button></div>`
    :summaryHtml(A)+(A.keys.length?`<div class="acts"><button data-a="keyNext">⏩ Key moments (${A.keys.length})</button></div>`:'');
  const bb=document.querySelector('.rv .bub');if(bb)bb.scrollTop=0;paintNav()}
function evBar(fen,k){const w=winPct(R.A.cpW(k)),e=$('#evf');e.style.height=w+'%';e.style.top=R.flip?'0':'auto';e.style.bottom=R.flip?'auto':'0'}
function paintNav(){document.querySelectorAll('.mv').forEach(e=>e.classList.remove('cur'));const m=$('#m'+R.k);const ml=$('#ml');if(m&&ml){m.classList.add('cur');ml.scrollTop=m.offsetTop-ml.clientHeight/2}
  $('#gk').setAttribute('x1',(R.k/Math.max(1,R.A.M.length))*300);$('#gk').setAttribute('x2',(R.k/Math.max(1,R.A.M.length))*300)}
function setK(k){stopLine();R.retry=null;R.k=Math.max(0,Math.min(R.A.M.length,k));showPos()}
ACT.rk=p=>setK(p==='end'?1e5:p==='start'?0:p==='prev'?R.k-1:p==='next'?R.k+1:+p.slice(1));
ACT.keyNext=()=>{const nx=R.A.keys.find(i=>i+1>R.k);setK(nx!==undefined?nx+1:(R.A.keys[0]+1||0))};
ACT.arrowTog=()=>{R.arrow=!R.arrow;showPos()};
ACT.graph=(p,el,e)=>{const r=el.getBoundingClientRect();setK(Math.round((e.clientX-r.left)/r.width*R.A.M.length))};
function stopLine(){stopAuto();if(R&&R.pv){clearTimeout(R.pv.t);R.pv=null}}
function stopAuto(){if(R&&R.auto){clearInterval(R.auto);R.auto=null;const b=$('#pl');if(b)b.textContent='▶'}}
ACT.play=()=>{if(R.auto){stopAuto();return}stopLine();R.retry=null;if(R.k>=R.A.M.length)R.k=0;showPos();$('#pl').textContent='⏸';
  R.auto=setInterval(()=>{if(R.k>=R.A.M.length){stopAuto();return}R.k++;showPos()},1400)};
ACT.line=w=>{const A=R.A,k=R.k,fen=w==='best'?A.fens[k-1]:A.fens[k],pv=w==='best'?A.res[k-1].pv:A.res[k].pv;stopLine();
  const c=new Chess(fen),fs=[fen],mv=[];for(const u of pv.slice(0,8)){const m=applyUci(c,u);if(!m)break;fs.push(c.fen());mv.push(u)}
  R.pv={fs,mv,k:0};stepLine()};
function stepLine(){const p=R.pv;if(!p)return;const u=p.k?p.mv[p.k-1]:null;
  renderBoard($('#bd'),p.fs[p.k],{flip:R.flip,last:u?[u.slice(0,2),u.slice(2,4)]:null});evBar(p.fs[p.k],R.k);
  if(p.k<p.mv.length){p.k++;p.t=setTimeout(stepLine,950)}}
// "try the best move" training
ACT.tryIt=()=>{stopLine();R.retry={c:new Chess(R.A.fens[R.k-1]),sel:null,tg:[]};drawRetry('Find the best move for '+(R.A.M[R.k-1].color==='w'?'White':'Black')+'.')};
function drawRetry(msg){const r=R.retry;renderBoard($('#bd'),r.c.fen(),{flip:R.flip,sel:r.sel,tg:r.tg,tap:retryTap});if(msg)$('#cb').innerHTML=`<p><b>${msg}</b></p><div class="acts"><button data-a="rk" data-p="k${R.k}">Back</button></div>`}
function retryTap(sq){const r=R.retry,A=R.A,x=A.M[R.k-1];
  if(r.sel){const mv=r.c.moves({square:r.sel,verbose:true}).filter(m=>m.to===sq);
    if(mv.length){const u=mv[0].from+mv[0].to+(mv[0].promotion?'q':'');r.sel=null;r.tg=[];
      if(u.slice(0,4)===x.best.slice(0,4)){applyUci(r.c,x.best);drawRetry('✅ Yes! '+x.bestSan+' is the best move.');return}
      return drawRetry('❌ Not the best move. Try again, or tap ▶ Best line to see it.')}}
  const p=r.c.get(sq);if(p&&p.color===r.c.turn()){r.sel=sq;r.tg=r.c.moves({square:sq,verbose:true}).map(m=>m.to)}else{r.sel=null;r.tg=[]}
  drawRetry()}

// ===== settings =====
function Settings(){applyTheme();
  app.innerHTML=hdr(t('settings'))+`<div class="pad"><h3>${t('language')}</h3><div class="langs">${Object.keys(LANGS).map(l=>`<span class="chip${LANG===l?' on':''}" data-a="lang" data-p="${l}">${LANGS[l]}</span>`).join('')}</div>
<h3>${t('theme')}</h3><div class="themes">${Object.keys(THEMES).map(k=>`<div class="sw${S.theme===k?' on':''}" data-a="theme" data-p="${k}"><div style="background:${THEMES[k][0]}"></div><div style="background:${THEMES[k][1]}"></div></div>`).join('')}</div>
<h3>${t('backup')}</h3><button class="btn" data-a="bkStorage">💾 ${t('toStorage')}</button><button class="btn" data-a="rsStorage">📂 ${t('fromStorage')}</button><button class="btn" data-a="bkPlay">🎮 ${t('toPlay')}</button>
<p class="small" style="margin-top:20px">Elo Grinder 1.0 · Maia + Stockfish · 100% offline</p></div>`}
ACT.lang=l=>{LANG=S.lang=l;saveS();Settings()};
ACT.theme=k=>{S.theme=k;saveS();Settings()};
ACT.bkStorage=()=>{const d=new Date().toISOString().slice(0,10),json=JSON.stringify(S);try{Android.saveFile('elogrinder-backup-'+d+'.json',json)}catch(e){toast('Not available')}};
ACT.rsStorage=()=>{try{Android.pickFile('backup')}catch(e){toast('Not available')}};
ACT.bkPlay=()=>{let m='Not available';try{m=Android.playGamesBackup(JSON.stringify(S))}catch(e){}modal(`<p>${esc(m)}</p><button class="btn" data-a="close">OK</button>`)};
function restore(text){try{const o=JSON.parse(text);if(!o.ratings||!o.games)throw 0;S=Object.assign(defaults(),o);LANG=S.lang;saveS();toast(t('restored'));stack=[];swap(Home)}catch(e){toast(t('bad'))}}

applyTheme();swap(Home);
window.onerror=(m,u,l)=>{try{toast('Error: '+m+' (line '+l+')')}catch(e){}};
