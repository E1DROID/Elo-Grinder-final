// UCI bridge to the native engines (stockfish = review, lc0 = Maia bots)
const E={h:{},chain:{},ok:{},net:0};
window.onEngine=(n,l)=>{const f=E.h[n];if(f)f(l)};
E.has=n=>{try{return !!(window.Android&&Android.engineAvailable(n))}catch(e){return false}};
E.raw=(n,cmds,until,ms)=>new Promise(res=>{const L=[];const to=setTimeout(()=>{E.h[n]=null;res(L)},ms||20000);
  E.h[n]=l=>{L.push(l);if(l.indexOf(until)===0){clearTimeout(to);E.h[n]=null;res(L)}};cmds.forEach(c=>Android.engineSend(n,c))});
E.q=(n,cmds,until,ms)=>{const p=(E.chain[n]||Promise.resolve()).then(()=>E.raw(n,cmds,until,ms));E.chain[n]=p.catch(()=>{});return p};
E.init=async n=>{if(E.ok[n])return true;if(!E.has(n))return false;
  try{Android.engineStart(n);const u=await E.q(n,['uci'],'uciok',15000);if(!u.some(l=>l.indexOf('uciok')===0))return false;
    if(n==='stockfish')await E.q(n,['setoption name Threads value 2','setoption name Hash value 32','setoption name MultiPV value 2','isready'],'readyok');
    else Android.engineSend(n,'setoption name Threads value 2');
    E.ok[n]=true;return true}catch(e){return false}};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function applyUci(c,u){return c.move({from:u.slice(0,2),to:u.slice(2,4),promotion:u[4]||undefined})}
const MV={p:1,n:3,b:3,r:5,q:9,k:0};

function weighted(mv){const w=mv.map(m=>m.captured?3:/[+#]/.test(m.san)?2:1);let r=Math.random()*w.reduce((a,b)=>a+b,0);for(let i=0;i<mv.length;i++){r-=w[i];if(r<=0)return mv[i]}return mv[0]}
function greedy(mv){let b=null,bs=-1e9;for(const m of mv){const s=(m.captured?MV[m.captured]:0)+(m.promotion?8:0)+(/[+#]/.test(m.san)?.4:0)+Math.random()*1.2;if(s>bs){bs=s;b=m}}return b}

/** Pick a bot move. Maia net nearest to the bot Elo (1100-1900). Below 1100 the bot also blunders randomly;
 *  above 1900 Maia-1900 gets extra search nodes. Falls back to a simple engine if lc0 is unavailable. */
async function botPick(chess,elo){
  const mv=chess.moves({verbose:true});if(!mv.length)return null;
  if(elo<1100&&Math.random()<(1100-elo)/1100*0.5)return weighted(mv);
  if(await E.init('lc0')){
    try{
      const net=Math.min(1900,Math.max(1100,Math.round(elo/100)*100));
      if(E.net!==net){await E.q('lc0',['setoption name WeightsFile value '+Android.maiaDir()+'/maia-'+net+'.pb.gz','isready'],'readyok',40000);E.net=net}
      const nodes=elo>1900?1+Math.round((elo-1900)/60):1;
      const hist=chess.history({verbose:true}).map(m=>m.from+m.to+(m.promotion||'')).join(' ');
      const L=await E.q('lc0',['position startpos'+(hist?' moves '+hist:''),'go nodes '+nodes],'bestmove',25000);
      const b=L.find(l=>l.indexOf('bestmove')===0),u=b&&b.split(' ')[1];
      const m=u&&mv.find(x=>x.from+x.to+(x.promotion||'')===u);if(m)return m;
    }catch(e){}
  }
  return greedy(mv);
}
