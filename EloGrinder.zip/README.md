# Elo Grinder
Offline chess app: **Elo Grind** (vs Maia bots, Glicko ratings per format), **Game Analyzer** (history, PGN import, Stockfish review with "Brilliant Trainer"), **Settings** (language, board theme, backup).

## Build the APK on GitHub
1. Create a new GitHub repo and upload the *contents* of this zip (keep `.github/` at the repo root).
2. Open **Actions > Build Elo Grinder APK > Run workflow** (it also runs on every push).
3. When it finishes, download the **EloGrinder-apk** artifact and install the APK (arm64 phones).

The workflow builds Stockfish 17 and lc0 (the engine that runs Maia) with the Android NDK, downloads the Maia 1100-1900 nets, fetches chess.js from npm, and packages everything. The first run takes ~15-25 min; engines are cached afterwards.

## How it works
- Engines are shipped as `libstockfish.so` / `liblc0.so` in `jniLibs` and executed from the native lib dir (see `MainActivity.java`).
- Bots: bot Elo is generated near your rating (+-~100). Maia net = nearest of 1100..1900. Below 1100 the bot also plays random blunders (more often the lower it is); above 1900 Maia-1900 gets extra nodes.
- Ratings: Glicko-1 per format (bullet / blitz / rapid / unlimited). Reset any format independently.
- Review: Stockfish depth 13, MultiPV 2, win%-based classification (brilliant, great, best, excellent, good, book, inaccuracy, mistake, miss, blunder), accuracy, eval graph, best-move arrows, "try the best move".

## Adding languages
Edit `app/src/main/assets/www/i18n.js` (copy the `en` block, add to `LANGS`).

## Play Games
`MainActivity.playGamesBackup()` is a stub. To enable: create a Play Games Services project in Play Console, add `com.google.android.gms:play-services-games-v2`, put your app id in the manifest meta-data `com.google.android.gms.games.APP_ID`, and implement Saved Games read/write of the JSON passed in. Storage backup (JSON file) already works.

## If the lc0 step fails
lc0's Meson option names change between releases. Check `meson_options.txt` in the cloned lc0 and adjust the `meson setup` flags in `build.yml`.
